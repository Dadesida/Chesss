# Write your code here :-)
class Move:

    def __init__(self, start,stop):
        # initial and final are squares
        self.start = start
        self.stop = stop

    def __str__(self):
        s = ''
        s += f'({self.start.col}, {self.start.row})'
        s += f' -> ({self.stop.col}, {self.stop.row})'
        return s

    def __eq__(self, other):
        return self.start == other.start and self.stop == other.stop
