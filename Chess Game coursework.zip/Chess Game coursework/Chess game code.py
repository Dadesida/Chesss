import pygame
from Board import *
import sys # Helps quit the game
from game import Game
from MouseDragger import Dragger
from square import Square
from Moves import Move



class Main:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode( (Width,Height) )#Window diameters
        pygame.display.set_caption('Chess Masters')# Name of the window
        self.game = Game()

    def main_loop(self):



        screen = self.screen
        game = self.game
        board = self.game.board
        dragger = self.game.dragger


        while True:

            game.show_bg(screen)#showing background
            game.show_last_move(screen)
            game.show_moves(screen)# showing the available move to play
            game.show_pieces(screen)# presenting the pieces on the board
            game.show_hover(screen)# show the current postion the dragger is on

            if dragger.dragging:
                dragger.image_update_pos(screen)# If the dragger dragger is dragging update the image of the piece

            for event in pygame.event.get():


                if event.type == pygame.MOUSEBUTTONDOWN:#When the mthe mouse is clicked
                    dragger.update_mouse(event.pos)# Updating the postion of the mouse position

                    clicked_row = dragger.mouseY // SQSIZE
                    clicked_col = dragger.mouseX // SQSIZE


                    if board.squares[clicked_row][clicked_col].has_piece():# If the square clicked has a piece then
                        piece = board.squares[clicked_row][clicked_col].piece

                        if piece.color == game.next_player:
                            board.calc_moves(piece, clicked_row, clicked_col, bool=True)
                            dragger.save_start(event.pos)# saving the strating postion of the piece
                            dragger.drag_piece(piece)

                            game.show_bg(screen)
                            game.show_last_move(screen)
                            game.show_moves(screen)
                            game.show_pieces(screen)


                elif event.type == pygame.MOUSEMOTION:# The motion of the mouse throughout the game
                    motion_row = event.pos[1] // SQSIZE
                    motion_col = event.pos[0] // SQSIZE

                    game.set_hover(motion_row, motion_col)#

                    if dragger.dragging:
                        dragger.update_mouse(event.pos)

                        game.show_bg(screen)#background
                        game.show_last_move(screen)#
                        game.show_moves(screen)# Available moves
                        game.show_pieces(screen)# displaying pieces on the board
                        game.show_hover(screen)# Highlighted square
                        dragger.image_update_pos(screen)


                elif event.type == pygame.MOUSEBUTTONUP:# when the mouse is relased

                    if dragger.dragging:
                        dragger.update_mouse(event.pos)

                        released_row = dragger.mouseY // SQSIZE
                        released_col = dragger.mouseX // SQSIZE


                        initial = Square(dragger.start_row, dragger.start_col)#starting square
                        final = Square(released_row, released_col)
                        move = Move(initial, final)


                        if board.valid_move(dragger.piece, move):

                            captured = board.squares[released_row][released_col].has_piece()
                            board.move(dragger.piece, move)

                            board.true_en_passant(dragger.piece)


                            game.play_sound(captured)# When piece is captured play the sound
                            #Updates
                            game.show_bg(screen)
                            game.show_last_move(screen)
                            game.show_pieces(screen)
                            # next turn
                            game.next_turn()

                    dragger.undrag_piece()

                # key press
                elif event.type == pygame.KEYDOWN:# Code to show when button is pressed


                    if event.key == pygame.K_t:# When t is presssed the background is changed
                        game.change_background()


                    if event.key == pygame.K_r:# When R is pressed the game is restarted
                        game.reset()
                        game = self.game
                        board = self.game.board
                        dragger = self.game.dragger


                elif event.type == pygame.QUIT:# This is used to close the opened windoe
                    pygame.quit()
                    sys.exit()

            pygame.display.update()


main = Main()
main.main_loop()
