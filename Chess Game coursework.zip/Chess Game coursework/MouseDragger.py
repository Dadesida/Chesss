import pygame
from Board import *
class Dragger:

    def __init__(self):
        self.piece=None# the piece we are dragging
        self.dragging=False#when nothing is being dragged it's set to false
        self.mouseX=0# x coordinates
        self.mouseY=0#y coordinates
        self.start_row=0
        self.start_col=0


    def image_update_pos(self,surface):
        self.piece.set_texture(size=128)# the piece size should increase when picked up to show it the one being played
        texture=self.piece.texture

        img=pygame.image.load(texture)

        img_center=(self.mouseX,self.mouseY)#Centering the image on dragger

        self.piece.texture_rect=img.get_rect(center=img_center)

        surface.blit(img,self.piece.texture_rect)# updating the visual position


    def update_mouse(self,pos):
        self.mouseX,self.mouseY=pos

    def save_start(self,pos):
        self.start_row= pos[1]//SQSIZE
        self.start_col= pos[0]//SQSIZE

    def drag_piece(self,piece):
        self.piece= piece# when the piece is being dragged set the value to true
        self.dragging=True

    def undrag_piece(self):#When the piece is unclicked the value is then set to false
        self.piece=None
        self.dragging=False
