#Creation of the board and window size
#Screen Dimensions
Width= 800
Height = 800

# Board dimensions
ROWS = 8
COLS = 8
SQSIZE = Width // COLS



#####

#Rule Book dimensions

R_Height= 600

R_Width=600




