import pygame
from Board import *
from ChessPieces import Board
from MouseDragger import Dragger

from Configuration import Config
from square import Square

class Game:

    def __init__(self):
        self.next_player = 'white'
        self.hovered_sqr = None
        self.board = Board()
        self.dragger = Dragger()
        self.config = Config()



    def show_bg(self, surface):# The background of the which is the board
        theme = self.config.theme

        for row in range(ROWS):
            for col in range(COLS):

                color = theme.bg.light if (row + col) % 2 == 0 else theme.bg.dark

                rect = (col * SQSIZE, row * SQSIZE, SQSIZE, SQSIZE)

                pygame.draw.rect(surface, color, rect)


                if col == 0:

                    color = theme.bg.dark if row % 2 == 0 else theme.bg.light

                    lbl = self.config.font.render(str(ROWS-row), 1, color)
                    lbl_pos = (5, 5 + row * SQSIZE)

                    surface.blit(lbl, lbl_pos)


                if row == 7:

                    color = theme.bg.dark if (row + col) % 2 == 0 else theme.bg.light

                    lbl = self.config.font.render(Square.get_alphacol(col), 1, color)
                    lbl_pos = (col * SQSIZE + SQSIZE - 20, Height - 20)

                    surface.blit(lbl, lbl_pos)

    def show_pieces(self, surface):
        for row in range(ROWS):
            for col in range(COLS):

                if self.board.squares[row][col].has_piece():
                    piece = self.board.squares[row][col].piece


                    if piece is not self.dragger.piece:# If the piece isnt i being dragged its size should be 80
                        piece.set_texture(size=80)
                        img = pygame.image.load(piece.texture)#loading the image
                        img_center = col * SQSIZE + SQSIZE // 2, row * SQSIZE + SQSIZE // 2
                        piece.texture_rect = img.get_rect(center=img_center)
                        surface.blit(img, piece.texture_rect)

    def show_moves(self, surface):
        theme = self.config.theme

        if self.dragger.dragging:
            piece = self.dragger.piece


            for move in piece.moves:# Going through all valid moves in a loop

                color = theme.moves.light if (move.stop.row + move.stop.col) % 2 == 0 else theme.moves.dark

                rect = (move.stop.col * SQSIZE, move.stop.row * SQSIZE, SQSIZE, SQSIZE)

                pygame.draw.rect(surface, color, rect)

    def show_last_move(self, surface):
        theme = self.config.theme

        if self.board.last_move:
            start = self.board.last_move.start
            stop = self.board.last_move.stop

            for pos in [start, stop]:

                color = theme.trace.light if (pos.row + pos.col) % 2 == 0 else theme.trace.dark

                rect = (pos.col * SQSIZE, pos.row * SQSIZE, SQSIZE, SQSIZE)

                pygame.draw.rect(surface, color, rect)

    def show_hover(self, surface):
        if self.hovered_sqr:

            color = (180, 180, 180)

            rect = (self.hovered_sqr.col * SQSIZE, self.hovered_sqr.row * SQSIZE, SQSIZE, SQSIZE)

            pygame.draw.rect(surface, color, rect, width=3)



    def next_turn(self):
        self.next_player = 'white' if self.next_player == 'black' else 'black'# used to give each user a turn and make sure white always starts

    def set_hover(self, row, col):
        self.hovered_sqr = self.board.squares[row][col]

    def change_background(self):
        self.config.change_background()

    def play_sound(self, captured=False):
        if captured:
            self.config.capture_sound.play()
        else:
            self.config.move_sound.play()

    def reset(self):
        self.__init__()
