# Write your code here :-)
from Board import *
from square import Square
from Pieces import *
from Moves import Move
from Sound import Sound
import copy
import os



class Board:

    def __init__(self):
        self.squares = [[0, 0, 0, 0, 0, 0, 0, 0] for col in range(COLS)]
        self.last_move = None
        self._create()
        self._add_pieces('white')
        self._add_pieces('black')

    def move(self, piece, move, testing=False):
        start = move.start# starting square
        stop = move.stop# final square

        en_passant_empty = self.squares[stop.row][stop.col].isempty()


        self.squares[start.row][start.col].piece = None# removing the piece from its intial postion
        self.squares[stop.row][stop.col].piece = piece

        if piece.name=="pawn":

            diff = stop.col - start.col# Coding en passant
            if diff != 0 and en_passant_empty:

                self.squares[start.row][start.col + diff].piece = None
                self.squares[stop.row][stop.col].piece = piece
                if not testing:
                    sound = Sound(
                        os.path.join('assets/sounds/capture.wav'))
                    sound.play()


            else:
                self.check_promotion(piece, stop)

        #
        if piece.name=="king": # castling of the King class
            if self.castling(start, stop) and not testing:
                diff = stop.col - start.col
                rook = piece.left_rook if (diff < 0) else piece.right_rook
                self.move(rook, rook.moves[-1])


        piece.moved = True# Set to true when castling has taken place


        piece.remove_moves()

        self.last_move = move

    def valid_move(self, piece, move):#
        return move in piece.moves#returning valid moves

    def check_promotion(self, piece,stop):
        if stop.row == 0 or stop.row == 7:
            self.squares[stop.row][stop.col].piece = Queen(piece.color)

    def castling(self, start, stop):
        return abs(start.col - stop.col) == 2

    def true_en_passant(self, piece):

        if not isinstance(piece, Pawn):
            return

        for row in range(ROWS):
            for col in range(COLS):
                if isinstance(self.squares[row][col].piece, Pawn):
                    self.squares[row][col].piece.en_passant = False

        piece.en_passant = True

    def in_check(self, piece, move):
        temp_piece = copy.deepcopy(piece)
        temp_board = copy.deepcopy(self)
        temp_board.move(temp_piece, move, testing=True)

        for row in range(ROWS):
            for col in range(COLS):
                if temp_board.squares[row][col].has_enemy_piece(piece.color):
                    p = temp_board.squares[row][col].piece
                    temp_board.calc_moves(p, row, col, bool=False)
                    for m in p.moves:
                        if isinstance(m.stop.piece, King):
                            return True

        return False

    def calc_moves(self, piece, row, col, bool=True):# Calculating each possible/ valid moves


        def pawn_moves():

            steps = 1 if piece.moved else 2# the amount of steps a pawn is allowed to take


            starting = row + piece.dir# starting row of the piece adding direction to it
            end = row + (piece.dir * (1 + steps))
            for possible_move_row in range(starting, end, piece.dir):# going through each row that a pawn can move to
                if Square.in_range(possible_move_row):# if the square is range of possible move
                    if self.squares[possible_move_row][col].isempty():# checking if square is empty


                        start = Square(row, col)# creating the starting and final squares
                        stop = Square(possible_move_row, col)

                        move = Move(start, stop)# Creating the new piece of the move


                        if bool:
                            if not self.in_check(piece, move):

                                piece.add_move(move)
                        else:

                            piece.add_move(move)

                    else: break#If  the square empty it will break denying the movement of the piece

                else: break# If the move is not in range disallow the move

            possible_move_row = row + piece.dir# Diagonal movements
            possible_move_cols = [col-1, col+1]
            for possible_move_col in possible_move_cols:
                if Square.in_range(possible_move_row, possible_move_col):
                    if self.squares[possible_move_row][possible_move_col].has_enemy_piece(piece.color):
                        # create start square and stop move squares
                        start = Square(row, col)
                        final_piece = self.squares[possible_move_row][possible_move_col].piece
                        stop = Square(possible_move_row, possible_move_col, final_piece)
                        # create a new move
                        move = Move(start, stop)


                        if bool:
                            if not self.in_check(piece, move):

                                piece.add_move(move)
                        else:

                            piece.add_move(move)


            r = 3 if piece.color == 'white' else 4# en passant moves
            fr = 2 if piece.color == 'white' else 5

            if Square.in_range(col-1) and row == r:
                if self.squares[row][col-1].has_enemy_piece(piece.color):#Left enpassant
                    p = self.squares[row][col-1].piece
                    if isinstance(p, Pawn):
                        if p.en_passant:

                            start = Square(row, col)
                            stop = Square(fr, col-1, p)

                            move = Move(start, stop)


                            if bool:
                                if not self.in_check(piece, move):

                                    piece.add_move(move)
                            else:

                                piece.add_move(move)


            if Square.in_range(col+1) and row == r:# coding the right side of en passant
                if self.squares[row][col+1].has_enemy_piece(piece.color):
                    p = self.squares[row][col+1].piece
                    if isinstance(p, Pawn):
                        if p.en_passant:

                            start = Square(row, col)
                            stop = Square(fr, col+1, p)

                            move = Move(start, stop)


                            if bool:#checking the potential move
                                if not self.in_check(piece, move):
                                    # append new move
                                    piece.add_move(move)
                            else:
                                # append new move
                                piece.add_move(move)


        def knight_moves():

            possible_moves = [
                (row-2, col+1),
                (row-1, col+2),
                (row+1, col+2),
                (row+2, col+1),
                (row+2, col-1),
                (row+1, col-2),
                (row-1, col-2),
                (row-2, col-1),
            ]

            for possible_move in possible_moves:
                possible_move_row, possible_move_col = possible_move

                if Square.in_range(possible_move_row, possible_move_col):
                    if self.squares[possible_move_row][possible_move_col].isempty_or_enemy(piece.color):

                        start = Square(row, col)
                        final_piece = self.squares[possible_move_row][possible_move_col].piece
                        stop = Square(possible_move_row, possible_move_col, final_piece)

                        move = Move(start, stop)

                        if bool:
                            if not self.in_check(piece, move):

                                piece.add_move(move)
                            else: break
                        else:

                            piece.add_move(move)

        def straightline_moves(incrs):# These would be used for the Bishop,Rook and Queen
            for incr in incrs:# incrementing through each move that each piece is allowed to do
                row_incr, col_incr = incr
                possible_move_row = row + row_incr
                possible_move_col = col + col_incr

                while True:
                    if Square.in_range(possible_move_row, possible_move_col):

                        start = Square(row, col)
                        final_piece = self.squares[possible_move_row][possible_move_col].piece
                        stop = Square(possible_move_row, possible_move_col, final_piece)

                        move = Move(start,stop)


                        if self.squares[possible_move_row][possible_move_col].isempty():

                            if bool:
                                if not self.in_check(piece, move):# Checking if any checks are placed

                                    piece.add_move(move)# appends the new move
                            else:

                                piece.add_move(move)


                        elif self.squares[possible_move_row][possible_move_col].has_enemy_piece(piece.color):

                            if bool:
                                if not self.in_check(piece, move):

                                    piece.add_move(move)
                            else:

                                piece.add_move(move)
                            break


                        elif self.squares[possible_move_row][possible_move_col].has_team_piece(piece.color):# Stops when coming into contact with team piece
                            break

                    # not in range
                    else: break


                    possible_move_row = possible_move_row + row_incr
                    possible_move_col = possible_move_col + col_incr

        def king_moves():
            adjs = [
                (row-1, col+0), # up
                (row-1, col+1), # up-right
                (row+0, col+1), # right
                (row+1, col+1), # down-right
                (row+1, col+0), # down
                (row+1, col-1), # down-left
                (row+0, col-1), # left
                (row-1, col-1), # up-left
            ]


            for possible_move in adjs:
                possible_move_row, possible_move_col = possible_move

                if Square.in_range(possible_move_row, possible_move_col):
                    if self.squares[possible_move_row][possible_move_col].isempty_or_enemy(piece.color):

                        start = Square(row, col)#Starting square
                        stop = Square(possible_move_row, possible_move_col) # Stops at all possible moves indecated

                        move = Move(start, stop)# makes the moves

                        if bool:
                            if not self.in_check(piece, move):# Deneies if the king is made in check

                                piece.add_move(move)
                            else: break
                        else:

                            piece.add_move(move)


            if not piece.moved:# Castling with the left rook and king

                left_rook = self.squares[row][0].piece
                if isinstance(left_rook, Rook):
                    if not left_rook.moved:
                        for c in range(1, 4):
                            # castling is not possible because there are pieces in between ?
                            if self.squares[row][c].has_piece():
                                break

                            if c == 3:# Adds the king with the rook

                                piece.left_rook = left_rook

                                # Rook movement after the castling has taken place
                                start = Square(row, 0)
                                stop = Square(row, 3)
                                moveR = Move(start, stop)

                                #Kings move after the castiling has taken place
                                start = Square(row, col)
                                stop = Square(row, 2)
                                moveK = Move(start, stop)


                                if bool:
                                    if not self.in_check(piece, moveK) and not self.in_check(left_rook, moveR):

                                        left_rook.add_move(moveR)# Adds the new move to the rook

                                        piece.add_move(moveK)# Adds the new move to the king
                                else:

                                    left_rook.add_move(moveR)

                                    piece.add_move(moveK)


                right_rook = self.squares[row][7].piece
                if isinstance(right_rook, Rook):
                    if not right_rook.moved:
                        for c in range(5, 7):

                            if self.squares[row][c].has_piece():# Makes castiling impossible if they're pieces between
                                break

                            if c == 6:

                                piece.right_rook = right_rook


                                start = Square(row, 7)
                                stop = Square(row, 5)
                                moveR = Move(start, stop)


                                start = Square(row, col)
                                stop = Square(row, 6)
                                moveK = Move(start, stop)

                                # check potencial checks
                                if bool:
                                    if not self.in_check(piece, moveK) and not self.in_check(right_rook, moveR):

                                        right_rook.add_move(moveR)

                                        piece.add_move(moveK)
                                else:
                                    # append new move to rook
                                    right_rook.add_move(moveR)
                                    # append new move king
                                    piece.add_move(moveK)

        if piece.name == "pawn":
            pawn_moves()

        elif piece.name=="knight":
            knight_moves()

        elif piece.name=="bishop":
            straightline_moves([
                (-1, 1), # up-right
                (-1, -1), # up-left
                (1, 1), # down-right
                (1, -1), # down-left
            ])

        elif piece.name=="rook":
            straightline_moves([
                (-1, 0), # up
                (0, 1), # right
                (1, 0), # down
                (0, -1), # left
            ])

        elif piece.name=="queen": # Copied the moves of rook and bishop into Quuen
            straightline_moves([
                (-1, 1), # up-right
                (-1, -1), # up-left
                (1, 1), # down-right
                (1, -1), # down-left
                (-1, 0), # up
                (0, 1), # right
                (1, 0), # down
                (0, -1) # left
            ])

        elif piece.name=="king":
            king_moves()

    def _create(self):
        for row in range(ROWS):
            for col in range(COLS):
                self.squares[row][col] = Square(row, col)

    def _add_pieces(self, color):
        row_pawn, row_other = (6, 7) if color == 'white' else (1, 0)

        # placement of pawns on each indvidual square
        for col in range(COLS):
            self.squares[row_pawn][col] = Square(row_pawn, col, Pawn(color))

        # placement of knights
        self.squares[row_other][1] = Square(row_other, 1, Knight(color))
        self.squares[row_other][6] = Square(row_other, 6, Knight(color))

        # placements of bishop
        self.squares[row_other][2] = Square(row_other, 2, Bishop(color))
        self.squares[row_other][5] = Square(row_other, 5, Bishop(color))

        # placements of rooks
        self.squares[row_other][0] = Square(row_other, 0, Rook(color))
        self.squares[row_other][7] = Square(row_other, 7, Rook(color))

        # placement of queen
        self.squares[row_other][3] = Square(row_other, 3, Queen(color))

        # placement of king
        self.squares[row_other][4] = Square(row_other, 4, King(color))# Write your code here :-)
