import pygame
from Board import *


class Game:
    def __init__(self):
        pass

    def show_bg(self,surface):
        for row in range(Rows):
            for coloumn in range (Coloumns):
                if (row+coloumn) % 2==0:
                    color=(234,235,200)#Light green
                else:
                    color-(119,154,88)#dark green

                rect=(col=SquareDimensions,row=SquareDimensions,SquareDimensions,SquareDimensions)

                pygame.draw.rext(surface,color,rect)
