from ChessPieces import *
import numpy
import random
from Pieces import *
import chess


class ChessBoard:
    def __init__(self):

        self.board = [
            ["r", "n", "b", "q", "k", "b", "n", "r"],# This will help me identify each piece on the board and where they're positioned
            ["p", "p", "p", "p", "p", "p", "p", "p"],
            [" ", " ", " ", " ", " ", " ", " ", " "],
            [" ", " ", " ", " ", " ", " ", " ", " "],
            [" ", " ", " ", " ", " ", " ", " ", " "],
            [" ", " ", " ", " ", " ", " ", " ", " "],
            ["P", "P", "P", "P", "P", "P", "P", "P"],
            ["R", "N", "B", "Q", "K", "B", "N", "R"]
        ]



class Heuristics:# creating a table to show how much each piece is worth depending on their position

    PAWN_TABLE = numpy.array([
	        [ 0,  0,  0,  0,  0,  0,  0,  0],
	        [ 5, 10, 10,-20,-20, 10, 10,  5],
	        [ 5, -5,-10,  0,  0,-10, -5,  5],
	        [ 0,  0,  0, 20, 20,  0,  0,  0],
	        [ 5,  5, 10, 25, 25, 10,  5,  5],
	        [10, 10, 20, 30, 30, 20, 10, 10],
	        [50, 50, 50, 50, 50, 50, 50, 50],
	        [ 0,  0,  0,  0,  0,  0,  0,  0]
	    ])
	

    KNIGHT_TABLE = numpy.array([
        [-50, -40, -30, -30, -30, -30, -40, -50],
        [-40, -20,   0,   5,   5,   0, -20, -40],
        [-30,   5,  10,  15,  15,  10,   5, -30],
        [-30,   0,  15,  20,  20,  15,   0, -30],
        [-30,   5,  15,  20,  20,  15,   0, -30],
        [-30,   0,  10,  15,  15,  10,   0, -30],
        [-40, -20,   0,   0,   0,   0, -20, -40],
        [-50, -40, -30, -30, -30, -30, -40, -50]
    ])
	

    BISHOP_TABLE = numpy.array([
        [-20, -10, -10, -10, -10, -10, -10, -20],
        [-10,   5,   0,   0,   0,   0,   5, -10],
        [-10,  10,  10,  10,  10,  10,  10, -10],
        [-10,   0,  10,  10,  10,  10,   0, -10],
        [-10,   5,   5,  10,  10,   5,   5, -10],
        [-10,   0,   5,  10,  10,   5,   0, -10],
        [-10,   0,   0,   0,   0,   0,   0, -10],
        [-20, -10, -10, -10, -10, -10, -10, -20]
	    ])
	

    Rook_table = numpy.array([
        [ 0,  0,  0,  5,  5,  0,  0,  0],
        [-5,  0,  0,  0,  0,  0,  0, -5],
        [-5,  0,  0,  0,  0,  0,  0, -5],
        [-5,  0,  0,  0,  0,  0,  0, -5],
        [-5,  0,  0,  0,  0,  0,  0, -5],
        [-5,  0,  0,  0,  0,  0,  0, -5],
        [ 5, 10, 10, 10, 10, 10, 10,  5],
        [ 0,  0,  0,  0,  0,  0,  0,  0]
    ])



	

    Queens_table = numpy.array([
        [-20, -10, -10, -5, -5, -10, -10, -20],
        [-10,   0,   5,  0,  0,   0,   0, -10],
        [-10,   5,   5,  5,  5,   5,   0, -10],
        [  0,   0,   5,  5,  5,   5,   0,  -5],
        [ -5,   0,   5,  5,  5,   5,   0,  -5],
        [-10,   0,   5,  5,  5,   5,   0, -10],
        [-10,   0,   0,  0,  0,   0,   0, -10],
        [-20, -10, -10, -5, -5, -10, -10, -20]
    ])

    @staticmethod
    def evaluate(Board):
        material = Heuristics.get_material_score(Board)
	

        pawns = Heuristics.get_piece_position_score(Board, pieces.Pawn, Heuristics.PAWN_TABLE)
        knights = Heuristics.get_piece_position_score(Board, pieces.Knight, Heuristics.KNIGHT_TABLE)
        bishops = Heuristics.get_piece_position_score(Board, pieces.Bishop, Heuristics.BISHOP_TABLE)
        rooks = Heuristics.get_piece_position_score(Board, pieces.Rook, Heuristics.ROOK_TABLE)
        queens = Heuristics.get_piece_position_score(Board, pieces.Queen, Heuristics.QUEEN_TABLE)

    def findRandomMove(valid_move):
        return valid_moves[random.randint(0,len(valid_moves)-1)]







