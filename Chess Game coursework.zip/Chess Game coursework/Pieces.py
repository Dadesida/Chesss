import os



class Pieces:
    def __init__(self,name,color,value,texture=None,texture_rect=None):
        self.name=name
        self.color=color
        value_sign = 1 if color == "white" else -1
        self.value = value*value_sign
        self.moves=[]# Adding the moves that has been palyed
        self.moved=False
        self.texture=texture
        self.set_texture()
        self.texture_rect=texture_rect# image on rectangle

    def set_texture(self,size=80):# the size of the image
        self.texture=os.path.join(
            f'assets/images/imgs-{size}px/{self.color}_{self.name}.png')   #Getting the images from the file

    def add_move(self,move):
        self.moves.append(move)# adding the move being played to the list

    def remove_moves(self):
        self.moves = []

class Pawn(Pieces):# All pieces inherit from the piece class
    def __init__(self,color):#inherits it color
        self.dir=-1 if color =="white" else 1# coding the direction of the pieces depending on the color
        super().__init__("pawn",color,1.0)#Ai will evaluate the board based on these values


class Knight(Pieces):
    def __init__(self,color):
        super().__init__("knight",color,3.001)# the name of the piece going along with its color and value

class Bishop(Pieces):
    def __init__(self,color):
        super().__init__("bishop",color,3.001)


class Rook(Pieces):
    def __init__(self,color):
        super().__init__("rook",color,5.0)

class Queen(Pieces):
    def __init__(self,color):
        super().__init__("queen",color,9.0)

class King(Pieces):
    def __init__(self,color):
        super().__init__("king",color,100000.0)


