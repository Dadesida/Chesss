# Write your code here :-)
import pygame
